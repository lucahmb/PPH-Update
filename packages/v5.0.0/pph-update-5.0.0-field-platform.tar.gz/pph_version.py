from __future__ import annotations
VERSION="5.0.0"
CHANNEL="stable"
BUILD_NAME="PPH 5.0.0 · Field Platform"
SCHEMA_VERSION=5
