from __future__ import annotations
VERSION="7.1.6"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.6 · Boot Intro Autostart Fix"
SCHEMA_VERSION=7
