from __future__ import annotations

VERSION = "2.9.4"
CHANNEL = "stable"
BUILD_NAME = "PPH Network Suite 2.9.4 · Restart Fix Stable"
SCHEMA_VERSION = 3
