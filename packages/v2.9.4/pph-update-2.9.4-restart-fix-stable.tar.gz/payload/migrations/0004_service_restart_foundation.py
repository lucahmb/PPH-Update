from __future__ import annotations

import os
import subprocess
from pathlib import Path

MIGRATION_ID = 4
DESCRIPTION = "PPH User-Services + robuster UI-Restart"


def _write(path: Path, content: str, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)
    path.chmod(mode)


def up(context) -> None:
    project = Path(context["project_root"]).resolve()
    home = Path(context["home"]).resolve()
    systemd = home / ".config" / "systemd" / "user"

    _write(systemd / "pph-hub.service", f'''[Unit]
Description=PPH Touch Hub
After=graphical-session.target
PartOf=graphical-session.target

[Service]
Type=simple
Environment=PPH_PROJECT_ROOT={project}
ExecStart={project / 'start_pph_hub.sh'}
Restart=on-failure
RestartSec=2

[Install]
WantedBy=default.target
''')

    _write(systemd / "pph-status.service", f'''[Unit]
Description=PPH Live Status Server
After=network.target

[Service]
Type=simple
WorkingDirectory={project}
Environment=PYTHONPATH={project}
ExecStart=/usr/bin/python3 {project / 'pph_status_server.py'}
Restart=on-failure
RestartSec=2

[Install]
WantedBy=default.target
''')

    _write(systemd / "pph-monitor.service", f'''[Unit]
Description=PPH Platform Monitor
After=network.target

[Service]
Type=simple
WorkingDirectory={project}
Environment=PYTHONPATH={project}
ExecStart=/usr/bin/python3 {project / 'pph_service_center.py'} --daemon
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
''')

    if os.environ.get("PPH_SKIP_SYSTEMD") == "1":
        return
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=False, capture_output=True, text=True, timeout=10)
        # Monitor + Status can be enabled immediately. Do not start a second Hub while the current GUI is still alive.
        subprocess.run(["systemctl", "--user", "enable", "pph-hub.service", "pph-status.service", "pph-monitor.service"], check=False, capture_output=True, text=True, timeout=15)
        subprocess.run(["systemctl", "--user", "restart", "pph-status.service", "pph-monitor.service"], check=False, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired):
        pass
