from __future__ import annotations
VERSION="7.0.0"
CHANNEL="stable"
BUILD_NAME="PPH 7.0.0 · Motion Redesign"
SCHEMA_VERSION=7
