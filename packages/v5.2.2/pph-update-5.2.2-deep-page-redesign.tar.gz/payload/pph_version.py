from __future__ import annotations
VERSION="5.2.2"
CHANNEL="stable"
BUILD_NAME="PPH 5.2.2 · Deep Page Redesign"
SCHEMA_VERSION=5
