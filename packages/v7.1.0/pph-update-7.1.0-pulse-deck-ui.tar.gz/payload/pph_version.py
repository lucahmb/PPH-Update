from __future__ import annotations
VERSION="7.1.0"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.0 · Pulse Deck UI"
SCHEMA_VERSION=7
