from __future__ import annotations
VERSION="5.0.2"
CHANNEL="stable"
BUILD_NAME="PPH 5.0.2 · Archive Layout Hotfix"
SCHEMA_VERSION=5
