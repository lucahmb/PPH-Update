from __future__ import annotations

VERSION = "3.2.0"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.2.0 · Field Analyzer"
SCHEMA_VERSION = 3
