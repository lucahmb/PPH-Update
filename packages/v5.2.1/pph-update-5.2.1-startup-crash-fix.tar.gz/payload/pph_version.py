from __future__ import annotations
VERSION="5.2.1"
CHANNEL="stable"
BUILD_NAME="PPH 5.2.1 · Startup Crash Fix"
SCHEMA_VERSION=5
