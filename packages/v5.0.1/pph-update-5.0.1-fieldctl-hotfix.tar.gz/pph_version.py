from __future__ import annotations
VERSION="5.0.1"
CHANNEL="stable"
BUILD_NAME="PPH 5.0.1 · Fieldctl Packaging Hotfix"
SCHEMA_VERSION=5
