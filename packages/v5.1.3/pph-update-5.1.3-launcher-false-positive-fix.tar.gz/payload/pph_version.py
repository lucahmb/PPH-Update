from __future__ import annotations
VERSION="5.1.3"
CHANNEL="stable"
BUILD_NAME="PPH 5.1.3 · Launcher False-Positive Fix"
SCHEMA_VERSION=5
