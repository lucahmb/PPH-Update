from __future__ import annotations

VERSION = "4.2.0"
CHANNEL = "stable"
BUILD_NAME = "PPH 4.2.0 · Full UI Rewrite"
SCHEMA_VERSION = 4
