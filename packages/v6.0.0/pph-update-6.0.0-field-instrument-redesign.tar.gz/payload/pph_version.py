from __future__ import annotations
VERSION="6.0.0"
CHANNEL="stable"
BUILD_NAME="PPH 6.0.0 · Field Instrument Redesign"
SCHEMA_VERSION=6
