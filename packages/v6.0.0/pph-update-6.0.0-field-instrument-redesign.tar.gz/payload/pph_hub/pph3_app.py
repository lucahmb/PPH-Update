#!/usr/bin/env python3
from __future__ import annotations

import polished_hub as hub
from pph3_ui import install
from pph32_ui import install as install32
from access_ui import install_access

install(hub.PolishedPPHApp, vars(hub))
install32(hub.PolishedPPHApp, vars(hub))
install_access(hub.PolishedPPHApp, vars(hub))

from pph4_theme import install as install4
install4(hub.PolishedPPHApp, vars(hub))

from pph41_ui import install as install41
install41(hub.PolishedPPHApp, vars(hub))

from pph411_touch import install as install411
install411(hub.PolishedPPHApp, vars(hub))

from pph412_paged import install as install412
install412(hub.PolishedPPHApp, vars(hub))

from pph42_full_ui import install as install42
install42(hub.PolishedPPHApp, vars(hub))

from pph50_platform import install as install50
install50(hub.PolishedPPHApp, vars(hub))

from pph51_ui import install as install51
install51(hub.PolishedPPHApp, vars(hub))

from pph6_ui import install as install6
install6(hub.PolishedPPHApp, vars(hub))

if __name__ == "__main__":
    raise SystemExit(hub.main())
