from __future__ import annotations

VERSION = "4.1.1"
CHANNEL = "stable"
BUILD_NAME = "PPH 4.1.1 · 5-inch Touch Layout"
SCHEMA_VERSION = 4
