from __future__ import annotations

import os
import subprocess
from pathlib import Path

MIGRATION_ID = 3
DESCRIPTION = "GitHub Stable Channel + täglicher Updatecheck"


def _write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)


def up(context) -> None:
    project_root = Path(context["project_root"]).resolve()
    home = Path(context["home"]).resolve()
    systemd = home / ".config" / "systemd" / "user"
    local_bin = home / ".local" / "bin"
    local_bin.mkdir(parents=True, exist_ok=True)

    _write(
        local_bin / "pph-update",
        f'''#!/usr/bin/env bash
exec /usr/bin/python3 "{project_root / 'pph_update_manager.py'}" "$@"
''',
    )
    (local_bin / "pph-update").chmod(0o755)

    _write(
        systemd / "pph-update-check.service",
        f'''[Unit]
Description=PPH GitHub Update Check
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
Environment=PYTHONPATH={project_root}
ExecStart=/usr/bin/python3 {project_root / 'pph_update_manager.py'} check --force --quiet
''',
    )
    _write(
        systemd / "pph-update-check.timer",
        '''[Unit]
Description=PPH daily GitHub update check

[Timer]
OnCalendar=daily
Persistent=true
AccuracySec=15m
Unit=pph-update-check.service

[Install]
WantedBy=timers.target
''',
    )

    if os.environ.get("PPH_SKIP_SYSTEMD") == "1":
        return
    try:
        subprocess.run(["systemctl", "--user", "daemon-reload"], check=False, capture_output=True, text=True, timeout=10)
        subprocess.run(["systemctl", "--user", "enable", "--now", "pph-update-check.timer"], check=False, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.TimeoutExpired):
        pass
