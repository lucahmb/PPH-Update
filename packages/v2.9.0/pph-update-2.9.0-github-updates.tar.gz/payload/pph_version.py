from __future__ import annotations

VERSION = "2.9.0"
CHANNEL = "stable"
BUILD_NAME = "PPH Network Suite 2.9 · GitHub Updates"
SCHEMA_VERSION = 3
