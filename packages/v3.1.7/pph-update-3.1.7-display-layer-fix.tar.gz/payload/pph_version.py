from __future__ import annotations

VERSION = "3.1.7"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.7 · Display Layer Fix"
SCHEMA_VERSION = 3
