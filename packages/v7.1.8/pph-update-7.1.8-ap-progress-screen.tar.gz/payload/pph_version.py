from __future__ import annotations
VERSION="7.1.8"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.8 · Access Point Progress Screen"
SCHEMA_VERSION=7
