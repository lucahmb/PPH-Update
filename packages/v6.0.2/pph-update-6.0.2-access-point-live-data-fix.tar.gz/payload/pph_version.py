from __future__ import annotations
VERSION="6.0.2"
CHANNEL="stable"
BUILD_NAME="PPH 6.0.2 · Access Point Live Data Fix"
SCHEMA_VERSION=6
