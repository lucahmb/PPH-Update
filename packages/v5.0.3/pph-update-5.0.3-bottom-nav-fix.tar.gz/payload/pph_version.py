from __future__ import annotations
VERSION="5.0.3"
CHANNEL="stable"
BUILD_NAME="PPH 5.0.3 · Bottom Navigation Fix"
SCHEMA_VERSION=5
