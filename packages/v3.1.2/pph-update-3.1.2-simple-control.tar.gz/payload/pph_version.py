from __future__ import annotations

VERSION = "3.1.2"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.2 · Simple Access Control"
SCHEMA_VERSION = 3
