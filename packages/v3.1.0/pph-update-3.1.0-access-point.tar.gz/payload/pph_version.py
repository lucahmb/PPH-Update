from __future__ import annotations

VERSION = "3.1.0"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.0 · Access Point"
SCHEMA_VERSION = 3
