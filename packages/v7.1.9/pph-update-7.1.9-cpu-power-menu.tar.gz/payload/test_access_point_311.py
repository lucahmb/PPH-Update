from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
HUB=ROOT/"pph_hub"
sys.path.insert(0,str(HUB))
from access_point import _digits,bars_for_speed
for _ in range(20):
    x=_digits(12); assert len(x)==12 and x.isdigit()
ui=(HUB/"access_ui.py").read_text(encoding="utf-8")
assert "WLAN-PASSWORT (12 ZIFFERN)" in ui
assert "password.isdigit()" in ui
print("PPH 3.1.1 tests OK")
