from __future__ import annotations

from pathlib import Path

import pph_services
import pph_update_manager as updates


def _manifest(version="3.0.1"):
    return {
        "product": "pph-funktest",
        "channel": "stable",
        "version": version,
        "released": "2026-08-09",
        "build_name": f"PPH {version}",
        "package_url": f"https://raw.githubusercontent.com/lucahmb/PPH-Update/main/packages/v{version}/pph-update-{version}.tar.gz",
        "sha256": "a" * 64,
        "min_version": "2.9.0",
        "max_version": "3.99.99",
        "notes": ["Test release"],
    }


def test_remote_manifest_validation():
    item = updates._normalize_remote_manifest(_manifest(), channel="stable")
    assert item["version"] == "3.0.1"
    assert item["channel"] == "stable"
    assert item["package_url"].startswith("https://raw.githubusercontent.com/")


def test_remote_cache_avoids_repeated_github_calls(tmp_path, monkeypatch):
    cache = tmp_path / "remote-check.json"
    monkeypatch.setattr(updates, "REMOTE_CACHE_FILE", cache)
    calls = {"count": 0}

    def fake_fetch(url, timeout=7.0):
        calls["count"] += 1
        return _manifest()

    monkeypatch.setattr(updates, "_fetch_json", fake_fetch)
    first = updates.check_remote(force=True)
    second = updates.check_remote(force=False)
    assert first["available"] is True
    assert second["available"] is True
    assert second["cached"] is True
    assert calls["count"] == 1


def test_non_github_download_url_rejected():
    bad = _manifest()
    bad["package_url"] = "https://example.com/update.tar.gz"
    try:
        updates._normalize_remote_manifest(bad, channel="stable")
    except updates.UpdateError:
        pass
    else:
        raise AssertionError("Fremder Updatehost wurde akzeptiert")


def test_update_timer_registered_in_service_manager():
    units = {item.unit for item in pph_services.SERVICES}
    assert "pph-update-check.timer" in units
