from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph42_full_ui.py').read_text()
a=(R/'pph_hub/pph3_app.py').read_text()
for x in ('home3','measure3','wifi3','system3','jobs3','events3','settings3','services','storage','hardware','reports','network','tools','network_doctor','lan_mapper','access3'): assert x in t
assert 'old.destroy()' in t
assert 'install42(hub.PolishedPPHApp, vars(hub))' in a
print('PPH 4.2.0 full UI tests OK')
