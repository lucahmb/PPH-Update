from pathlib import Path
R=Path(__file__).resolve().parent
ui=(R/'pph_hub/pph32_ui.py').read_text(encoding='utf-8')
launch=(R/'pph_hub/pph3_app.py').read_text(encoding='utf-8')
for x in ('PPH FIELD CENTER','PPH NETWORK ANALYZER','RADIO CENTER','PPH QUICK TEST','NETWORK DOCTOR','SELF-HEAL'):
    assert x in ui
assert 'install32(hub.PolishedPPHApp, vars(hub))' in launch
assert 'mt7921u' in (R/'pph_hub/access_point.py').read_text(encoding='utf-8')
print('PPH 3.2.0 tests OK')
