from __future__ import annotations
VERSION="7.1.9"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.9 · CPU Load & Power Menu"
SCHEMA_VERSION=7
