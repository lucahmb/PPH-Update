from pathlib import Path
ROOT=Path(__file__).resolve().parent
ui=(ROOT/"pph_hub/pph3_ui.py").read_text(encoding="utf-8")
assert 'controls.place(relx=1.0' in ui
assert 'fresh_stable_version' in ui
assert 'manual-fresh' in ui
assert 'Cache-Control' in ui
assert 'text="UPDATES"' in ui
print("PPH 3.1.5 tests OK")
