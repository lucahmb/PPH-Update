from pathlib import Path
import py_compile,sys
ROOT=Path(__file__).resolve().parent; HUB=ROOT/"pph_hub"
for p in (HUB/"access_point.py",HUB/"access_ui.py",ROOT/"fieldctl.py"):
    py_compile.compile(str(p),doraise=True)
ap=(HUB/"access_point.py").read_text(); ui=(HUB/"access_ui.py").read_text(); helper=(ROOT/"fieldctl.py").read_text()
assert '/usr/local/libexec/pph-ap-fieldctl' in ap
assert 'sudo","-n' in ap
assert 'DOCKER-USER' in helper and '10.42.0.0/24' in helper
assert 'mt7921u' in helper
assert 'PPH-WIFI erscheint automatisch' in ui
print('PPH 3.1.4 tests OK')
