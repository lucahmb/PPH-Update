from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph412_paged.py').read_text()
for x in ('PAGE 1 / 2','PAGE 2 / 2','font=self._font(30','pady=14','wireless412b','network412b'): assert x in t
print('PPH 4.1.2 tests OK')
