from pathlib import Path
ROOT=Path(__file__).resolve().parent
ui=(ROOT/"pph_hub/pph3_ui.py").read_text(encoding="utf-8")
ap=(ROOT/"pph_hub/access_point.py").read_text(encoding="utf-8")
assert 'controls.place(relx=1.0' in ui
assert 'fresh_stable_version' in ui
assert 'mt7921u' in ap
assert (ROOT/'fieldctl.py').exists()
assert (ROOT/'install_field_mode.sh').exists()
print("PPH 3.1.6 tests OK")
