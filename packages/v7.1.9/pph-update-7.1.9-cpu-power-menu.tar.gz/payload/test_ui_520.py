from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph51_ui.py').read_text(encoding='utf-8')
v=(R/'pph_version.py').read_text(encoding='utf-8')
for x in ('PPH 5.2 · TOUCH HUB','more52','ALLE KATEGORIEN','MESSUNG STARTEN','GERAET','menu_tile','badge.after(850'):
    assert x in t
assert 'VERSION="5.2.0"' in v
print('PPH 5.2.0 touch hub tests OK')
