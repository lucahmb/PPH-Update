from pathlib import Path
ROOT=Path(__file__).resolve().parent
ui=(ROOT/"pph_hub/pph3_ui.py").read_text(encoding="utf-8")
assert 'original_toggle_fullscreen = cls.toggle_fullscreen' in ui
assert 'header.lift()' in ui
assert 'controls.lift()' in ui
assert 'self.root.update_idletasks()' in ui
assert 'for delay in (0,40,120,300)' in ui
assert 'cls.toggle_fullscreen = toggle_fullscreen' in ui
print("PPH 3.1.7 tests OK")
