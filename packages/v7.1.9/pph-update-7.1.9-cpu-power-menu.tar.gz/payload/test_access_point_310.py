from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parent
HUB = ROOT / "pph_hub"
sys.path.insert(0, str(HUB))
from access_point import bars_for_speed
assert [bars_for_speed(x) for x in (0, 1, 10, 50, 100)] == [0, 1, 2, 3, 4]
ui=(HUB/"pph3_ui.py").read_text(encoding="utf-8")
app=(HUB/"pph3_app.py").read_text(encoding="utf-8")
assert '("ACCESS", "access3")' in ui
assert 'self.pph31_build_access()' in ui
assert 'install_access' in app
print("PPH 3.1 Access Point tests OK")
