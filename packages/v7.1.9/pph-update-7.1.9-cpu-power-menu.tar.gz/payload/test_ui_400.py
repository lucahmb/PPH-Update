from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph4_theme.py').read_text(encoding='utf-8')
app=(R/'pph_hub/pph3_app.py').read_text(encoding='utf-8')
for x in ('WIRELESS SITE ANALYZER','FIELD INTERFACE','_page_anim','_skin','pph4_status_pulse','START MEASUREMENT'):
    assert x in t
assert 'install4(hub.PolishedPPHApp, vars(hub))' in app
assert (R/'pph_hub/pph32_ui.py').exists()
assert (R/'pph_hub/access_ui.py').exists()
print('PPH 4.0.0 visual tests OK')
