from pathlib import Path
import py_compile
R=Path(__file__).resolve().parent
ui=R/'pph_hub/pph51_ui.py'
py_compile.compile(str(ui), doraise=True)
t=ui.read_text(encoding='utf-8')
assert "left.grid(row=0,column=0" not in t, 'two_cards() must not grid the card frames into an unrelated container'
assert "left.pack(side='left'" in t and "right.pack(side='left'" in t
for marker in ('visual_page','scanline','p51_visual','HARDWARE','STORAGE','SERVICES','NETWORK DOCTOR','LAN MAPPER','Visuelle PPH 5.2 Detailseite'):
    assert marker in t
assert 'def _release_reset' in t and 'except Exception:pass' in t
print('PPH 5.2.2 deep page redesign tests OK')
