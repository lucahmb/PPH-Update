from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph411_touch.py').read_text(encoding='utf-8')
a=(R/'pph_hub/pph3_app.py').read_text(encoding='utf-8')
for x in ('800×480 TOUCH','WIRELESS ANALYZER','NETWORK ANALYZER','Touch-optimierte Steuerung','pady=11'):
    assert x in t
assert 'install411(hub.PolishedPPHApp, vars(hub))' in a
print('PPH 4.1.1 5-inch tests OK')
