from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent; HUB=ROOT/"pph_hub"; sys.path.insert(0,str(HUB))
from access_point import _digits
for _ in range(20):
    x=_digits(4); assert len(x)==4 and x.isdigit()
ap=(HUB/"access_point.py").read_text(); ui=(HUB/"access_ui.py").read_text()
assert '"lan_ip": _ipv4(lan)' in ap
assert 'accepted' in ap
assert 'AKTUELLE PI-IP' in ui
assert 'AP-IP: 10.42.0.1' in ui
assert 'pph-ap-ui-start' in ui
print("PPH 3.1.3 tests OK")
