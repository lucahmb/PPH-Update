from pathlib import Path
R=Path(__file__).resolve().parent
t=(R/'pph_hub/pph41_ui.py').read_text(encoding='utf-8')
for x in ('FIELD COMMAND CENTER','WIRELESS SITE ANALYZER','NETWORK ANALYZER','FIELD OS','ACCESS POINT','SETTINGS'):
 assert x in t
assert 'install41(hub.PolishedPPHApp, vars(hub))' in (R/'pph_hub/pph3_app.py').read_text(encoding='utf-8')
print('PPH 4.1 tests OK')
