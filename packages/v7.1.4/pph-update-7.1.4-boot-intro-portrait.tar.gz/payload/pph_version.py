from __future__ import annotations
VERSION="7.1.4"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.4 · Boot Intro Portrait Rebuild"
SCHEMA_VERSION=7
