from __future__ import annotations

VERSION = "3.1.1"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.1 · Access Point Fix"
SCHEMA_VERSION = 3
