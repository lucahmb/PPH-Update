from __future__ import annotations

VERSION = "3.1.5"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.5 · UI + Update Refresh Fix"
SCHEMA_VERSION = 3
