from __future__ import annotations
VERSION="7.1.1"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.1 · Boot Intro"
SCHEMA_VERSION=7
