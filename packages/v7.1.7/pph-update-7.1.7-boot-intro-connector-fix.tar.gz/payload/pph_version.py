from __future__ import annotations
VERSION="7.1.7"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.7 · Boot Intro Connector Fix"
SCHEMA_VERSION=7
