from __future__ import annotations

VERSION = "2.9.2"
CHANNEL = "stable"
BUILD_NAME = "PPH Network Suite 2.9.2 · Restart Fix"
SCHEMA_VERSION = 3
