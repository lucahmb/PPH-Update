from __future__ import annotations

VERSION = "4.0.0"
CHANNEL = "stable"
BUILD_NAME = "PPH 4.0.0 · Visual Overhaul"
SCHEMA_VERSION = 4
