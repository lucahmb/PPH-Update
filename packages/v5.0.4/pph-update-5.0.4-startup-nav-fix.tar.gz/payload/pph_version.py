from __future__ import annotations
VERSION="5.0.4"
CHANNEL="stable"
BUILD_NAME="PPH 5.0.4 · Startup Navigation Fix"
SCHEMA_VERSION=5
