from __future__ import annotations

VERSION = "4.1.2"
CHANNEL = "stable"
BUILD_NAME = "PPH 4.1.2 · Paged 5-inch Touch UI"
SCHEMA_VERSION = 4
