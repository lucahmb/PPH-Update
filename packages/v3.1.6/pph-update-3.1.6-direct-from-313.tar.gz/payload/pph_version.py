from __future__ import annotations

VERSION = "3.1.6"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.6 · Direct Upgrade Fix"
SCHEMA_VERSION = 3
