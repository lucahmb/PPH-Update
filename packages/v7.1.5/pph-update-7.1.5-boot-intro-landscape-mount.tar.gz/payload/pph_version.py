from __future__ import annotations
VERSION="7.1.5"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.5 · Boot Intro Landscape Mount Fix"
SCHEMA_VERSION=7
