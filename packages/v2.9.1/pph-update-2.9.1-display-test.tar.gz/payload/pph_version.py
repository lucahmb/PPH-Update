from __future__ import annotations

VERSION = "2.9.1"
CHANNEL = "stable"
BUILD_NAME = "PPH Network Suite 2.9.1 · Update Pipeline Test"
SCHEMA_VERSION = 3
