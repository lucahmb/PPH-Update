from __future__ import annotations

import pph_update_manager
import pph_version


def test_version_291():
    assert pph_version.VERSION == "2.9.1"
    assert pph_version.CHANNEL == "stable"
    assert pph_version.SCHEMA_VERSION >= 3


def test_update_version_order():
    assert pph_update_manager._version_tuple("2.9.1") > pph_update_manager._version_tuple("2.9.0")
