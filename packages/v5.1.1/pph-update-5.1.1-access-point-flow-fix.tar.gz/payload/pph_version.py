from __future__ import annotations
VERSION="5.1.1"
CHANNEL="stable"
BUILD_NAME="PPH 5.1.1 · Access Point + Connection Flow Fix"
SCHEMA_VERSION=5
