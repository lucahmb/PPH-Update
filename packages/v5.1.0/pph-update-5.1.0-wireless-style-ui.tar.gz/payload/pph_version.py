from __future__ import annotations
VERSION="5.1.0"
CHANNEL="stable"
BUILD_NAME="PPH 5.1.0 · Wireless Style System UI"
SCHEMA_VERSION=5
