from __future__ import annotations
VERSION="7.1.2"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.2 · Boot Intro Fix"
SCHEMA_VERSION=7
