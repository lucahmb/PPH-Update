from __future__ import annotations

VERSION = "4.1.0"
CHANNEL = "stable"
BUILD_NAME = "PPH 4.1.0 · Visual Relaunch"
SCHEMA_VERSION = 4
