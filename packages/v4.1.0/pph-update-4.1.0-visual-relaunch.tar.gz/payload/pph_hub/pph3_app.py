#!/usr/bin/env python3
from __future__ import annotations

import polished_hub as hub
from pph3_ui import install
from pph32_ui import install as install32
from access_ui import install_access

install(hub.PolishedPPHApp, vars(hub))
install32(hub.PolishedPPHApp, vars(hub))
install_access(hub.PolishedPPHApp, vars(hub))

from pph4_theme import install as install4
install4(hub.PolishedPPHApp, vars(hub))

from pph41_ui import install as install41
install41(hub.PolishedPPHApp, vars(hub))

if __name__ == "__main__":
    raise SystemExit(hub.main())
