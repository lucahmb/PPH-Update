from __future__ import annotations
VERSION="6.0.1"
CHANNEL="stable"
BUILD_NAME="PPH 6.0.1 · Topbar Version Control"
SCHEMA_VERSION=6
