from __future__ import annotations
VERSION="5.2.0"
CHANNEL="stable"
BUILD_NAME="PPH 5.2.0 · Touch Hub Redesign"
SCHEMA_VERSION=5
