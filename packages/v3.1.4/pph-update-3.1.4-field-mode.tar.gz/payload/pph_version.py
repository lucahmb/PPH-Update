from __future__ import annotations

VERSION = "3.1.4"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.4 · Field Mode"
SCHEMA_VERSION = 3
