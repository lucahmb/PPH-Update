from __future__ import annotations
VERSION="5.1.2"
CHANNEL="stable"
BUILD_NAME="PPH 5.1.2 · Startup Crash Fix"
SCHEMA_VERSION=5
