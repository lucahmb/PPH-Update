from __future__ import annotations

VERSION = "3.1.3"
CHANNEL = "stable"
BUILD_NAME = "PPH 3.1.3 · Current IP Control"
SCHEMA_VERSION = 3
