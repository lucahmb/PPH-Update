from __future__ import annotations
VERSION="7.1.3"
CHANNEL="stable"
BUILD_NAME="PPH 7.1.3 · Boot Intro Orientation Fix"
SCHEMA_VERSION=7
